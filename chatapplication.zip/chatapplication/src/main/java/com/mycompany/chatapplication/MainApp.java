/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapplication;

/**
 *
 * @author Student
 */
import java.util.Scanner;

public class MainApp {
    public static void main(String[]args){
        
        //Scanner will allow user to input information
       Scanner input = new Scanner(System.in);
       
       //you create an object of login class to call its method
       Login login = new Login();
       
       
    //----This is were the registration happens----   
    System.out.println("=== USER REGISTRATION ===");
    
    System.out.print("Enter a username: ");
    String username = input.nextLine();
    
    System.out.print("Enter a password: ");
    String password = input.nextLine();
    
    System.out.print("Enter your South African number (+27...):");
    String phoneNumber = input.nextLine();
      
    //This is the register method which stores the mesage it retores
     String response = login.registerUser(username, password, phoneNumber);
     
     //Shows registration method
     System.out.println(response);
     
     System.out.println("\n=== USER LOGIN ===");
     
     System.out.print("Enter your username: ");
      String loginUsername = input.nextLine();
              
       System.out.print("Enter your password: ");
      String loginPassword = input.nextLine();  
      
      //This checks the stored details whether they match or not
      boolean loggedIn = login.loginUser(loginUsername, loginPassword);
      
      //Prints correct message
      String loginMessage = login.returnLoginStatus(loggedIn);
      System.out.println(loginMessage);
      
}
}
